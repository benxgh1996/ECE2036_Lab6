#ifndef STARTUPJINGLE_H
#define STARTUPJINGLE_H

class GameJingle {
    public:
    void playIntro();
    void playExit();
};


#endif
